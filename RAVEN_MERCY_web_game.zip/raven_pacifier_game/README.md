# RAVEN // MERCY — Crimson Eclipse Protocol

A playable, offline-capable browser prototype built around the uploaded crimson-energy MOV, the floating white-faced hooded companion, the gothic-city video, and the raven-inspired androgynous 3D character.

## Launch

Unzip the folder and **open `index.html` in Chrome, Firefox, Safari or Edge**. No server, dependencies, package installation, API key, or internet connection is required. For a hosted web build, upload the whole folder, retaining `assets/` next to `index.html`.

## Keyboard / mouse

| Key | Function |
|---|---|
| WASD / arrows | Float in the open world |
| Shift | Accelerate |
| Space | Ascend visually |
| E | Charge crimson wings, phase-float into the nearest/selected robot, infuse a pacification charge |
| Q | Circular pacification shockwave |
| Click on target | Select robot / synth / humanoid / sentinel |
| Click on ground | Autopilot float to location |
| F | Toggle automatic pacification when targets are in range |
| B | Open upgrade menu |
| Esc | Pause/resume |

Mobile: on-screen joystick, PHASE, PULSE, and + upgrades buttons.

## Design

- Procedural scrolling urban area (approximately 12 x 12 km coordinate field) with layered cathedral-city video imagery and stylized 2.5D architecture.
- Floating Raven playable lead (red/ivory robe, raven black hair, charcoal-violet body, lace-up high-top tech sneakers).
- Echo AI companion (hooded white face and red headband) follows and periodically pacifies enemies.
- Original MOV-inspired action: **gather energy → crimson wings bloom → glide through enemy → violet mercy ring → ally transformation**.
- Nonlethal gameplay: enemies become allies; nothing explodes to pieces.
- Escalating waves, faster robots, more difficult synths and humanoids, sentinel on every fourth wave.
- Mercy rewards track and upgradeable abilities (thrusters, resonance, companion, regeneration).
- All visual rendering and physics are JavaScript Canvas 2D with 2.5D projection and high resolution / DPR rendering. The phrase “64-bit-like” is interpreted as a polished high-color aesthetic, **not** a literal graphics bit depth or full skeletal 3D rig.

## Reference files

`assets/raven_hero.webp` — visual reference for player
`assets/companion.jpg` — companion image from video
`assets/city.jpg` — gothic megacity reference
`assets/reference_motion.mp4` — short H.264 copy of MOV for viewing in the menu
`assets/city_motion.mp4` — optional compressed city footage for future cinematic use

This is a runnable prototype, not a GLB/FBX 3D character mesh or commercial-scale game engine. The in-world sprites are drawn procedurally. To take it further, replace those sprites with rigged models in Three.js/Babylon.js/Unity.
